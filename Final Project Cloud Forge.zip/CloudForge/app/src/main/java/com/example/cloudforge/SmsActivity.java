
package com.example.cloudforge;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsActivity extends AppCompatActivity {

    private static final String TAG = "CloudForgeSMS";

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    private static final String USER_ID_EXTRA =
            "com.example.cloudforge.USER_ID";

    private static final String PREFS_NAME =
            "cloudforge_sms_settings";

    private static final String PHONE_KEY = "phone_";
    private static final String ENABLED_KEY = "enabled_";

    private long userId;

    private EditText phoneField;
    private TextView textPermissionStatus;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (view, insets) -> {

                    Insets bars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    view.setPadding(
                            bars.left,
                            bars.top,
                            bars.right,
                            bars.bottom
                    );

                    return insets;
                }
        );

        userId = getIntent().getLongExtra(
                USER_ID_EXTRA,
                -1L
        );

        if (userId <= 0) {
            Toast.makeText(
                    this,
                    "Please log in before changing SMS settings.",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        preferences = getSharedPreferences(
                PREFS_NAME,
                MODE_PRIVATE
        );

        textPermissionStatus = findViewById(
                R.id.textPermissionStatus
        );

        Button buttonAllowSms = findViewById(
                R.id.buttonAllowSms
        );

        Button buttonNotNow = findViewById(
                R.id.buttonNotNow
        );

        // Add the phone number input to the existing
        // SMS screen without modifying the XML layout.

        setupPhoneNumberField();

        phoneField.setText(
                preferences.getString(
                        PHONE_KEY + userId,
                        ""
                )
        );

        buttonAllowSms.setText("Enable SMS Alerts");
        buttonNotNow.setText("Disable SMS Alerts");

        buttonAllowSms.setOnClickListener(
                view -> enableSmsAlerts()
        );

        buttonNotNow.setOnClickListener(
                view -> disableSmsAlerts()
        );

        updatePermissionStatus();
    }

    private void setupPhoneNumberField() {

        LinearLayout parent =
                (LinearLayout) textPermissionStatus.getParent();

        TextView label = new TextView(this);

        label.setText("SMS Recipient Phone Number");
        label.setTextSize(16);
        label.setTextColor(0xFF1F2937);

        LinearLayout.LayoutParams labelParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

        labelParams.topMargin = dp(20);

        phoneField = new EditText(this);

        phoneField.setHint("Enter phone number");
        phoneField.setInputType(
                InputType.TYPE_CLASS_PHONE
        );

        phoneField.setSingleLine(true);
        phoneField.setTextSize(16);

        LinearLayout.LayoutParams inputParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(56)
                );

        inputParams.topMargin = dp(8);

        int position = parent.indexOfChild(
                textPermissionStatus
        );

        parent.addView(
                label,
                position,
                labelParams
        );

        parent.addView(
                phoneField,
                position + 1,
                inputParams
        );
    }

    private int dp(int value) {

        return Math.round(
                value * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    private String normalizedPhone() {

        return phoneField.getText()
                .toString()
                .trim()
                .replaceAll("[\\s()\\-]", "");
    }

    private boolean validPhone(String phone) {

        return phone.matches("\\+?[0-9]{7,15}");
    }

    private boolean permissionGranted() {

        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void enableSmsAlerts() {

        String phone = normalizedPhone();

        if (!validPhone(phone)) {

            phoneField.setError(
                    "Enter a valid phone number"
            );

            phoneField.requestFocus();

            Toast.makeText(
                    this,
                    "A valid recipient phone number is required.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (permissionGranted()) {

            saveSettings(phone, true);

            updatePermissionStatus();

            Toast.makeText(
                    this,
                    "SMS alerts enabled",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            // Save the entered number, but do not
            // enable alerts until permission is granted.

            saveSettings(phone, false);

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    private void disableSmsAlerts() {

        String phone = normalizedPhone();

        saveSettings(phone, false);

        updatePermissionStatus();

        Toast.makeText(
                this,
                "SMS alerts disabled",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void saveSettings(
            String phone,
            boolean enabled) {

        preferences.edit()
                .putString(
                        PHONE_KEY + userId,
                        phone
                )
                .putBoolean(
                        ENABLED_KEY + userId,
                        enabled
                )
                .apply();
    }

    private void updatePermissionStatus() {

        if (textPermissionStatus == null
                || preferences == null) {
            return;
        }

        boolean granted = permissionGranted();

        boolean enabled = preferences.getBoolean(
                ENABLED_KEY + userId,
                false
        );

        String phone = preferences.getString(
                PHONE_KEY + userId,
                ""
        );

        String status;

        if (!granted) {

            status =
                    "SMS permission not granted.\n\n" +
                            "Inventory management will continue " +
                            "to work without SMS alerts.";

        } else if (enabled && validPhone(phone)) {

            status =
                    "SMS Alerts: ENABLED\n\n" +
                            "Recipient: " + phone + "\n\n" +
                            "Low-stock alerts are configured.";

        } else {

            status =
                    "SMS Permission: GRANTED\n\n" +
                            "Low-stock alerts are disabled.\n\n" +
                            "Enter a phone number and select " +
                            "Enable SMS Alerts.";
        }

        textPermissionStatus.setText(status);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (textPermissionStatus != null) {
            updatePermissionStatus();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode != SMS_PERMISSION_REQUEST_CODE) {
            return;
        }

        boolean granted =
                grantResults.length > 0
                        && grantResults[0]
                        == PackageManager.PERMISSION_GRANTED;

        String phone = normalizedPhone();

        saveSettings(
                phone,
                granted && validPhone(phone)
        );

        updatePermissionStatus();

        Toast.makeText(
                this,
                granted
                        ? "SMS permission granted"
                        : "SMS permission denied",
                Toast.LENGTH_LONG
        ).show();
    }

    // Called by InventoryActivity when a stock
    // quantity reaches or falls below its threshold.
    //
    // Returns true when an SMS send request was accepted,
    // not proof that the message was delivered.

    @SuppressWarnings("deprecation")
    public static boolean sendLowStockAlert(
            Context context,
            long userId,
            String itemName,
            int quantity,
            int threshold) {

        if (userId <= 0 || quantity > threshold) {
            return false;
        }

        SharedPreferences settings =
                context.getSharedPreferences(
                        PREFS_NAME,
                        Context.MODE_PRIVATE
                );

        boolean enabled = settings.getBoolean(
                ENABLED_KEY + userId,
                false
        );

        if (!enabled) {
            return false;
        }

        String phone = settings.getString(
                PHONE_KEY + userId,
                ""
        );

        if (phone == null
                || !phone.matches("\\+?[0-9]{7,15}")) {
            return false;
        }

        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        String message =
                "CloudForge Low Stock Alert\n" +
                        "Item: " + itemName + "\n" +
                        "Quantity: " + quantity + "\n" +
                        "Threshold: " + threshold + "\n" +
                        "Restocking may be required.";

        try {

            SmsManager smsManager =
                    SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phone,
                    null,
                    message,
                    null,
                    null
            );

            Log.i(
                    TAG,
                    "Low-stock SMS request submitted."
            );

            return true;

        } catch (Exception e) {

            Log.e(
                    TAG,
                    "Unable to request low-stock SMS",
                    e
            );

            return false;
        }
    }
}
