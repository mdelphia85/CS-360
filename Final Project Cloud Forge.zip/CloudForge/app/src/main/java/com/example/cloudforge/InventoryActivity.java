
package com.example.cloudforge;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private static final String USER_ID_EXTRA =
            "com.example.cloudforge.USER_ID";

    private InventoryDatabase database;
    private long currentUserId;

    private TableLayout inventoryTable;

    private EditText itemNameField;
    private EditText quantityField;
    private EditText locationField;
    private EditText thresholdField;

    private boolean tableHasThresholdColumn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        View root = findViewById(R.id.main);

        ViewCompat.setOnApplyWindowInsetsListener(
                root,
                (view, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );

        currentUserId = Math.max(
                0L,
                getIntent().getLongExtra(USER_ID_EXTRA, 0L)
        );

        database = new InventoryDatabase(this);

        itemNameField = findViewById(R.id.editItemName);
        quantityField = findViewById(R.id.editQuantity);
        locationField = findViewById(R.id.editLocation);

        inventoryTable = findInventoryTable(root);

        if (inventoryTable == null) {
            showMessage("Inventory table could not be found.");
            finish();
            return;
        }

        if (inventoryTable.getChildCount() > 0
                && inventoryTable.getChildAt(0) instanceof TableRow) {

            TableRow header =
                    (TableRow) inventoryTable.getChildAt(0);

            tableHasThresholdColumn =
                    header.getChildCount() >= 5;
        }

        Button addButton = findViewById(R.id.buttonAddItem);

        setupThresholdField(addButton);

        addButton.setOnClickListener(
                view -> addInventoryItem()
        );

        Button notificationsButton =
                findViewById(R.id.buttonNotifications);

        notificationsButton.setOnClickListener(view -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    SmsActivity.class
            );

            intent.putExtra(
                    USER_ID_EXTRA,
                    currentUserId
            );

            startActivity(intent);
        });

        int logoutId = getResources().getIdentifier(
                "buttonLogout",
                "id",
                getPackageName()
        );

        if (logoutId != 0) {
            View logoutButton = findViewById(logoutId);

            if (logoutButton != null) {
                logoutButton.setOnClickListener(
                        view -> finish()
                );
            }
        }

        refreshInventory();
    }

    // Locate the inventory table in the existing XML layout.

    private TableLayout findInventoryTable(View view) {

        if (view instanceof TableLayout) {
            return (TableLayout) view;
        }

        if (view instanceof ViewGroup) {

            ViewGroup group = (ViewGroup) view;

            for (int i = 0; i < group.getChildCount(); i++) {

                TableLayout result = findInventoryTable(
                        group.getChildAt(i)
                );

                if (result != null) {
                    return result;
                }
            }
        }

        return null;
    }

    // Use the XML threshold field if present.
    // Otherwise add one to the existing screen in Java.

    private void setupThresholdField(Button addButton) {

        int thresholdId = getResources().getIdentifier(
                "editThreshold",
                "id",
                getPackageName()
        );

        if (thresholdId != 0) {
            thresholdField = findViewById(thresholdId);
        }

        if (thresholdField != null) {
            return;
        }

        if (!(addButton.getParent() instanceof LinearLayout)) {
            throw new IllegalStateException(
                    "Add Item button must be inside a LinearLayout"
            );
        }

        LinearLayout parent =
                (LinearLayout) addButton.getParent();

        thresholdField = new EditText(this);

        thresholdField.setHint("Low-stock threshold");
        thresholdField.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );
        thresholdField.setText("5");
        thresholdField.setSingleLine(true);
        thresholdField.setPadding(
                dp(12), dp(8), dp(12), dp(8)
        );

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(56)
                );

        params.topMargin = dp(12);

        int position = parent.indexOfChild(addButton);

        parent.addView(
                thresholdField,
                position,
                params
        );
    }

    // Validate nonnegative whole-number fields.

    private Integer readNumber(EditText field) {

        String value = field.getText().toString().trim();

        try {
            int number = Integer.parseInt(value);

            if (number >= 0) {
                return number;
            }

        } catch (NumberFormatException ignored) {
        }

        field.setError(
                "Enter a whole number of zero or greater"
        );

        return null;
    }

    // Add a new inventory record to SQLite.

    private void addInventoryItem() {

        String name =
                itemNameField.getText().toString().trim();

        String location =
                locationField.getText().toString().trim();

        if (name.isEmpty()) {
            itemNameField.setError("Item name is required");
            itemNameField.requestFocus();
            return;
        }

        if (location.isEmpty()) {
            locationField.setError("Location is required");
            locationField.requestFocus();
            return;
        }

        Integer quantity = readNumber(quantityField);
        Integer threshold = readNumber(thresholdField);

        if (quantity == null || threshold == null) {
            return;
        }

        long insertedId = database.addItem(
                currentUserId,
                name,
                quantity,
                location,
                threshold
        );

        if (insertedId == -1) {
            showMessage("Unable to save inventory item.");
            return;
        }

        itemNameField.setText("");
        quantityField.setText("");
        locationField.setText("");
        thresholdField.setText("5");

        refreshInventory();

        // Request SMS when a newly added item is low stock.

        if (quantity <= threshold) {

            boolean smsRequested = SmsActivity.sendLowStockAlert(
                    this,
                    currentUserId,
                    name,
                    quantity,
                    threshold
            );

            showMessage(
                    smsRequested
                            ? "Item added. Low-stock SMS requested."
                            : "Item added. Warning: stock is low."
            );

        } else {
            showMessage("Inventory item added.");
        }
    }

    // Refresh inventory from the SQLite database.

    private void refreshInventory() {

        // Keep the existing header row.
        // Remove the original static sample rows.

        int childCount = inventoryTable.getChildCount();

        if (childCount > 1) {
            inventoryTable.removeViews(
                    1,
                    childCount - 1
            );
        }

        List<InventoryItem> items =
                database.getItems(currentUserId);

        int emptyId = getResources().getIdentifier(
                "textEmptyInventory",
                "id",
                getPackageName()
        );

        if (emptyId != 0) {

            TextView emptyView = findViewById(emptyId);

            if (emptyView != null) {
                emptyView.setVisibility(
                        items.isEmpty()
                                ? View.VISIBLE
                                : View.GONE
                );
            }
        }

        for (InventoryItem item : items) {
            addTableRow(item);
        }
    }

    // Display a database item in the inventory table.

    private void addTableRow(InventoryItem item) {

        TableRow row = new TableRow(this);

        row.setPadding(
                dp(6),
                dp(5),
                dp(6),
                dp(5)
        );

        boolean lowStock =
                item.quantity <= item.threshold;

        row.setBackgroundColor(
                lowStock
                        ? Color.rgb(255, 229, 229)
                        : Color.WHITE
        );

        row.addView(
                createCell(item.name, 150, false)
        );

        row.addView(
                createCell(
                        String.valueOf(item.quantity),
                        80,
                        lowStock
                )
        );

        row.addView(
                createCell(item.location, 100, false)
        );

        if (tableHasThresholdColumn) {

            row.addView(
                    createCell(
                            String.valueOf(item.threshold),
                            80,
                            false
                    )
            );
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setTextSize(12);
        editButton.setAllCaps(false);
        editButton.setMinWidth(0);
        editButton.setMinimumWidth(0);

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setTextSize(12);
        deleteButton.setAllCaps(false);
        deleteButton.setMinWidth(0);
        deleteButton.setMinimumWidth(0);

        LinearLayout.LayoutParams editParams =
                new LinearLayout.LayoutParams(
                        dp(80),
                        dp(50)
                );

        LinearLayout.LayoutParams deleteParams =
                new LinearLayout.LayoutParams(
                        dp(80),
                        dp(50)
                );

        actions.addView(editButton, editParams);
        actions.addView(deleteButton, deleteParams);

        row.addView(
                actions,
                new TableRow.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        editButton.setOnClickListener(
                view -> showEditDialog(item)
        );

        deleteButton.setOnClickListener(
                view -> confirmDelete(item)
        );

        inventoryTable.addView(row);
    }

    private TextView createCell(
            String value,
            int width,
            boolean warning) {

        TextView cell = new TextView(this);

        cell.setText(value);
        cell.setTextSize(14);
        cell.setGravity(Gravity.CENTER_VERTICAL);

        cell.setTextColor(
                warning
                        ? Color.rgb(185, 28, 28)
                        : Color.rgb(31, 41, 55)
        );

        cell.setPadding(
                dp(5),
                dp(5),
                dp(5),
                dp(5)
        );

        cell.setMinHeight(dp(50));

        cell.setLayoutParams(
                new TableRow.LayoutParams(
                        dp(width),
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        return cell;
    }

    // Edit an existing inventory record.

    private void showEditDialog(InventoryItem item) {

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);

        form.setPadding(
                dp(20),
                dp(8),
                dp(20),
                dp(8)
        );

        EditText nameInput = createDialogField(
                "Item name",
                item.name,
                false
        );

        EditText quantityInput = createDialogField(
                "Quantity",
                String.valueOf(item.quantity),
                true
        );

        EditText locationInput = createDialogField(
                "Storage location",
                item.location,
                false
        );

        EditText thresholdInput = createDialogField(
                "Low-stock threshold",
                String.valueOf(item.threshold),
                true
        );

        form.addView(nameInput);
        form.addView(quantityInput);
        form.addView(locationInput);
        form.addView(thresholdInput);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("Edit Inventory Item")
                        .setView(form)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Save", null)
                        .create();

        dialog.setOnShowListener(ignored -> {

            Button saveButton = dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            );

            saveButton.setOnClickListener(view -> {

                String name =
                        nameInput.getText().toString().trim();

                String location =
                        locationInput.getText().toString().trim();

                if (name.isEmpty()) {
                    nameInput.setError("Name is required");
                    return;
                }

                if (location.isEmpty()) {
                    locationInput.setError(
                            "Location is required"
                    );
                    return;
                }

                Integer quantity =
                        readNumber(quantityInput);

                Integer threshold =
                        readNumber(thresholdInput);

                if (quantity == null || threshold == null) {
                    return;
                }

                boolean saved = database.updateItem(
                        currentUserId,
                        item.id,
                        name,
                        quantity,
                        location,
                        threshold
                );

                if (!saved) {
                    showMessage("Unable to update item.");
                    return;
                }

                dialog.dismiss();
                refreshInventory();

                // Request an SMS if the edited item becomes
                // low stock or its already-low quantity drops.

                if (quantity <= threshold) {

                    boolean newlyLow =
                            item.quantity > item.threshold;

                    boolean decreased =
                            quantity < item.quantity;

                    boolean smsRequested = false;

                    if (newlyLow || decreased) {

                        smsRequested = SmsActivity.sendLowStockAlert(
                                this,
                                currentUserId,
                                name,
                                quantity,
                                threshold
                        );
                    }

                    showMessage(
                            smsRequested
                                    ? "Item updated. Low-stock SMS requested."
                                    : "Item updated. Warning: low stock."
                    );

                } else {
                    showMessage("Inventory item updated.");
                }
            });
        });

        dialog.show();
    }

    private EditText createDialogField(
            String hint,
            String value,
            boolean numeric) {

        EditText field = new EditText(this);

        field.setHint(hint);
        field.setText(value);
        field.setSingleLine(true);

        field.setInputType(
                numeric
                        ? InputType.TYPE_CLASS_NUMBER
                        : InputType.TYPE_CLASS_TEXT
        );

        return field;
    }

    // Confirm before deleting an inventory record.

    private void confirmDelete(InventoryItem item) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Inventory Item")
                .setMessage(
                        "Are you sure you want to delete "
                                + item.name + "?"
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton(
                        "Delete",
                        (dialog, which) -> {

                            boolean deleted = database.deleteItem(
                                    currentUserId,
                                    item.id
                            );

                            if (deleted) {
                                refreshInventory();
                                showMessage(
                                        "Inventory item deleted."
                                );
                            } else {
                                showMessage(
                                        "Unable to delete item."
                                );
                            }
                        }
                )
                .show();
    }

    private int dp(int value) {

        return Math.round(
                value * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    private void showMessage(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }

    @Override
    protected void onDestroy() {

        if (database != null) {
            database.close();
        }

        super.onDestroy();
    }

    // Inventory data model.

    private static final class InventoryItem {

        final long id;
        final String name;
        final int quantity;
        final String location;
        final int threshold;

        InventoryItem(
                long id,
                String name,
                int quantity,
                String location,
                int threshold) {

            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.location = location;
            this.threshold = threshold;
        }
    }

    // Local SQLite database.
    // Same database name and schema as your working version.

    private static final class InventoryDatabase
            extends SQLiteOpenHelper {

        private static final String DATABASE_NAME =
                "cloudforge_inventory_local.db";

        private static final int DATABASE_VERSION = 1;

        InventoryDatabase(Context context) {

            super(
                    context,
                    DATABASE_NAME,
                    null,
                    DATABASE_VERSION
            );
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(
                    "CREATE TABLE inventory (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "owner_id INTEGER NOT NULL, " +
                            "name TEXT NOT NULL, " +
                            "quantity INTEGER NOT NULL " +
                            "CHECK(quantity >= 0), " +
                            "location TEXT NOT NULL, " +
                            "threshold INTEGER NOT NULL " +
                            "CHECK(threshold >= 0))"
            );

            db.execSQL(
                    "CREATE INDEX inventory_owner_index " +
                            "ON inventory(owner_id)"
            );
        }

        @Override
        public void onUpgrade(
                SQLiteDatabase db,
                int oldVersion,
                int newVersion) {

            // Initial database version.
        }

        long addItem(
                long ownerId,
                String name,
                int quantity,
                String location,
                int threshold) {

            ContentValues values = new ContentValues();

            values.put("owner_id", ownerId);
            values.put("name", name);
            values.put("quantity", quantity);
            values.put("location", location);
            values.put("threshold", threshold);

            return getWritableDatabase().insert(
                    "inventory",
                    null,
                    values
            );
        }

        List<InventoryItem> getItems(long ownerId) {

            List<InventoryItem> items = new ArrayList<>();

            try (Cursor cursor =
                         getReadableDatabase().query(
                                 "inventory",
                                 new String[]{
                                         "id",
                                         "name",
                                         "quantity",
                                         "location",
                                         "threshold"
                                 },
                                 "owner_id = ?",
                                 new String[]{
                                         String.valueOf(ownerId)
                                 },
                                 null,
                                 null,
                                 "name COLLATE NOCASE ASC"
                         )) {

                while (cursor.moveToNext()) {

                    items.add(
                            new InventoryItem(
                                    cursor.getLong(0),
                                    cursor.getString(1),
                                    cursor.getInt(2),
                                    cursor.getString(3),
                                    cursor.getInt(4)
                            )
                    );
                }
            }

            return items;
        }

        boolean updateItem(
                long ownerId,
                long itemId,
                String name,
                int quantity,
                String location,
                int threshold) {

            ContentValues values = new ContentValues();

            values.put("name", name);
            values.put("quantity", quantity);
            values.put("location", location);
            values.put("threshold", threshold);

            int updated = getWritableDatabase().update(
                    "inventory",
                    values,
                    "id = ? AND owner_id = ?",
                    new String[]{
                            String.valueOf(itemId),
                            String.valueOf(ownerId)
                    }
            );

            return updated == 1;
        }

        boolean deleteItem(long ownerId, long itemId) {

            int deleted = getWritableDatabase().delete(
                    "inventory",
                    "id = ? AND owner_id = ?",
                    new String[]{
                            String.valueOf(itemId),
                            String.valueOf(ownerId)
                    }
            );

            return deleted == 1;
        }
    }
}
