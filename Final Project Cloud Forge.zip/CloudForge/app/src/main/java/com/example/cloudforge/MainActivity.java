
package com.example.cloudforge;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID =
            "com.example.cloudforge.USER_ID";

    private static final String TAG = "CloudForgeAuth";

    private static final String INVENTORY_DB =
            "cloudforge_inventory_local.db";

    private EditText usernameField;
    private EditText passwordField;
    private TextView statusText;

    private AccountDatabase accountDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (view, insets) -> {
                    Insets bars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    view.setPadding(
                            bars.left,
                            bars.top,
                            bars.right,
                            bars.bottom
                    );

                    return insets;
                }
        );

        usernameField = findViewById(R.id.editUsername);
        passwordField = findViewById(R.id.editPassword);
        statusText = findViewById(R.id.textSecurity);

        Button loginButton =
                findViewById(R.id.buttonLogin);

        Button createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        accountDatabase = new AccountDatabase(this);

        statusText.setText(
                "Secure login active - Create an account first"
        );

        loginButton.setOnClickListener(view -> login());

        createAccountButton.setOnClickListener(
                view -> createAccount()
        );
    }

    private void showMessage(String message) {

        statusText.setText(message);

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }

    private boolean validateInputs(boolean registering) {

        String username =
                usernameField.getText().toString().trim();

        String password =
                passwordField.getText().toString();

        if (username.length() < 3 ||
                username.length() > 32 ||
                !username.matches("[A-Za-z0-9._-]+")) {

            usernameField.setError(
                    "Use 3-32 letters, numbers, dots, _ or -"
            );

            usernameField.requestFocus();

            showMessage("Enter a valid username");
            return false;
        }

        if (password.isEmpty()) {

            passwordField.setError(
                    "Password cannot be empty"
            );

            passwordField.requestFocus();

            showMessage("Enter your password");
            return false;
        }

        if (registering && password.length() < 8) {

            passwordField.setError(
                    "Use at least 8 characters"
            );

            passwordField.requestFocus();

            showMessage(
                    "New passwords must be at least 8 characters"
            );

            return false;
        }

        return true;
    }

    // CREATE ACCOUNT

    private void createAccount() {

        if (!validateInputs(true)) {
            return;
        }

        String username =
                usernameField.getText().toString().trim();

        String password =
                passwordField.getText().toString();

        try {

            long userId = accountDatabase.createAccount(
                    username,
                    password
            );

            if (userId == -1) {

                usernameField.setError(
                        "Username already exists"
                );

                showMessage(
                        "Account already exists. " +
                                "Log in or choose another username."
                );

                return;
            }

            if (!preserveExistingInventory(userId)) {
                return;
            }

            passwordField.setText("");

            showMessage(
                    "Account created successfully"
            );

            openInventory(userId);

        } catch (Exception e) {

            Log.e(TAG, "Account creation error", e);

            showMessage(
                    "Account creation failed: database error"
            );
        }
    }

    // LOG IN

    private void login() {

        if (!validateInputs(false)) {
            return;
        }

        String username =
                usernameField.getText().toString().trim();

        String password =
                passwordField.getText().toString();

        try {

            long userId = accountDatabase.authenticate(
                    username,
                    password
            );

            if (userId == -1) {

                passwordField.setText("");

                passwordField.setError(
                        "Incorrect username or password"
                );

                showMessage(
                        "Login failed: incorrect username or password"
                );

                return;
            }

            if (!preserveExistingInventory(userId)) {
                return;
            }

            passwordField.setText("");

            statusText.setText("Login successful");

            openInventory(userId);

        } catch (Exception e) {

            Log.e(TAG, "Login error", e);

            passwordField.setText("");

            showMessage(
                    "Login failed: unable to verify credentials"
            );
        }
    }

    // ONLY A VERIFIED USER CAN OPEN INVENTORY

    private void openInventory(long userId) {

        if (userId <= 0) {
            showMessage("Access denied");
            return;
        }

        Intent intent = new Intent(
                MainActivity.this,
                InventoryActivity.class
        );

        intent.putExtra(
                EXTRA_USER_ID,
                userId
        );

        startActivity(intent);
    }

    // PRESERVE INVENTORY FROM THE OLD PROJECT TWO LOGIN
    // Existing records were saved with owner_id = 0.
    // Associate them with the first real account.

    private boolean preserveExistingInventory(long userId) {

        if (userId != 1L) {
            return true;
        }

        File file = getDatabasePath(INVENTORY_DB);

        if (!file.exists()) {
            return true;
        }

        try (SQLiteDatabase db =
                     SQLiteDatabase.openDatabase(
                             file.getAbsolutePath(),
                             null,
                             SQLiteDatabase.OPEN_READWRITE
                     )) {

            try (Cursor cursor = db.rawQuery(
                    "SELECT name FROM sqlite_master " +
                            "WHERE type='table' AND name='inventory'",
                    null
            )) {

                if (!cursor.moveToFirst()) {
                    return true;
                }
            }

            db.execSQL(
                    "UPDATE inventory " +
                            "SET owner_id = ? " +
                            "WHERE owner_id = 0",
                    new Object[]{userId}
            );

            return true;

        } catch (Exception e) {

            Log.e(TAG, "Inventory migration error", e);

            showMessage(
                    "Saved inventory could not be associated " +
                            "with your account. No data was deleted."
            );

            return false;
        }
    }

    @Override
    protected void onDestroy() {

        if (accountDatabase != null) {
            accountDatabase.close();
        }

        super.onDestroy();
    }

    // SQLITE ACCOUNT DATABASE

    private static class AccountDatabase
            extends SQLiteOpenHelper {

        private static final String DATABASE_NAME =
                "cloudforge_auth.db";

        private static final int DATABASE_VERSION = 1;

        private static final int HASH_ITERATIONS = 120000;
        private static final int HASH_LENGTH = 256;

        private static final SecureRandom RANDOM =
                new SecureRandom();

        AccountDatabase(Context context) {
            super(
                    context,
                    DATABASE_NAME,
                    null,
                    DATABASE_VERSION
            );
        }

        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL(
                    "CREATE TABLE users (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "username TEXT NOT NULL COLLATE NOCASE UNIQUE, " +
                            "salt TEXT NOT NULL, " +
                            "password_hash TEXT NOT NULL)"
            );
        }

        @Override
        public void onUpgrade(
                SQLiteDatabase db,
                int oldVersion,
                int newVersion) {
            // Version 1 schema.
        }

        private String generateSalt() {

            byte[] salt = new byte[16];

            RANDOM.nextBytes(salt);

            return Base64.encodeToString(
                    salt,
                    Base64.NO_WRAP
            );
        }

        private String hashPassword(
                String password,
                String encodedSalt) {

            char[] passwordCharacters =
                    password.toCharArray();

            PBEKeySpec keySpec = null;

            try {

                byte[] salt = Base64.decode(
                        encodedSalt,
                        Base64.NO_WRAP
                );

                keySpec = new PBEKeySpec(
                        passwordCharacters,
                        salt,
                        HASH_ITERATIONS,
                        HASH_LENGTH
                );

                SecretKeyFactory factory =
                        SecretKeyFactory.getInstance(
                                "PBKDF2WithHmacSHA256"
                        );

                byte[] hash =
                        factory.generateSecret(keySpec)
                                .getEncoded();

                return Base64.encodeToString(
                        hash,
                        Base64.NO_WRAP
                );

            } catch (Exception e) {

                throw new IllegalStateException(
                        "Password hashing error",
                        e
                );

            } finally {

                Arrays.fill(
                        passwordCharacters,
                        '\0'
                );

                if (keySpec != null) {
                    keySpec.clearPassword();
                }
            }
        }

        // REGISTER ACCOUNT

        long createAccount(
                String username,
                String password) {

            String salt = generateSalt();

            String passwordHash =
                    hashPassword(password, salt);

            ContentValues values = new ContentValues();

            values.put(
                    "username",
                    username.trim()
            );

            values.put("salt", salt);

            values.put(
                    "password_hash",
                    passwordHash
            );

            try {

                return getWritableDatabase().insertOrThrow(
                        "users",
                        null,
                        values
                );

            } catch (SQLiteConstraintException e) {

                return -1;
            }
        }

        // VERIFY ACCOUNT AND PASSWORD

        long authenticate(
                String username,
                String password) {

            try (Cursor cursor =
                         getReadableDatabase().query(
                                 "users",
                                 new String[]{
                                         "id",
                                         "salt",
                                         "password_hash"
                                 },
                                 "username = ?",
                                 new String[]{
                                         username.trim()
                                 },
                                 null,
                                 null,
                                 null
                         )) {

                if (!cursor.moveToFirst()) {
                    return -1;
                }

                long userId = cursor.getLong(0);

                String salt = cursor.getString(1);
                String savedHash = cursor.getString(2);

                String suppliedHash =
                        hashPassword(password, salt);

                byte[] expected = Base64.decode(
                        savedHash,
                        Base64.NO_WRAP
                );

                byte[] actual = Base64.decode(
                        suppliedHash,
                        Base64.NO_WRAP
                );

                if (!MessageDigest.isEqual(
                        expected,
                        actual
                )) {
                    return -1;
                }

                return userId;

            } catch (IllegalArgumentException e) {

                return -1;
            }
        }
    }
}
